Project Title
RPN Calculator 1.0

Getting Started
Application will start from Executor Class, after Import this project on eclipse , run Executor class as java class. 
It will ask you for the input, enter the input such as "3 4 +" and press the "enter" you will get the output.
Or you can run the jar file that provided with java -jar "RPNCaculator.jar"

Prerequisites
Need one Java IDE such as eclips
JDK 8


Installing
Download the folder from github
open your eclipse
go to file 
then click on import
select as java project
then give the path where you keep your folder(that you have downloaded from git)
click finish



Running the tests
Run the test class , by giving your desire output


Built With
Eclipse - Java8
Maven - Dependency Management (Yet to use)

Versioning
Version controll plan to use in future

Future Task 
Complete all validation
add more methodology

Authors
Tanmaya Dey