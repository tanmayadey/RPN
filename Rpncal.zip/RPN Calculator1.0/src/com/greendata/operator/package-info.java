/**
 * 
 */
/**
 * @author tdey
 *
 */
package com.greendata.operator;