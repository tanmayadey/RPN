/**
 * 
 */
/**
 * @author tdey
 * this package contain all pojo class
 */
package com.greendata.pojo;