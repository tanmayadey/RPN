/**
 * 
 */
/**
 * @author tdey
 * this package contain executor class to start the application
 */
package com.greendata.exe;